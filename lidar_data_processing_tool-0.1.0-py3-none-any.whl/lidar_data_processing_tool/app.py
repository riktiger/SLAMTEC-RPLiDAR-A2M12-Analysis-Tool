
import gradio as gr
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots

# Updated plotting function with correct Cartesian conversion
def target_angle_range(df, min_angle_deg, max_angle_deg, min_cutoff=None, max_cutoff=None):
    """
    Plot LiDAR points in two views:
    1. Polar plot (angle vs range)
    2. Cartesian global view (X forward, Y lateral)
    Features:
    - Filters by angle and optional min/max range cutoffs.
    - Polar plot zooms to cutoff.
    - Cartesian plot shows global view (straight walls).
    - Adds annotation for LiDAR position at center.
    - Returns selected range and intensity values.
    """
    error_output = None

    # Ensure scalar values
    min_angle_deg = float(min_angle_deg)
    max_angle_deg = float(max_angle_deg)

    # Warning for angles beyond system limits
    if min_angle_deg > 180 or max_angle_deg > 180 or min_angle_deg < -179 or max_angle_deg < -179:
        error_output = "⚠️ Warning: LiDAR system operates from -179° to +180°. Angles outside this range may result in missing data in the plot."

    # Convert input degrees to radians
    min_angle_rad = np.deg2rad(min_angle_deg)
    max_angle_rad = np.deg2rad(max_angle_deg)

    # Clean DataFrame
    df = df.copy()
    df = df.iloc[:, 10:]  # Remove first 10 columns
    df = df.loc[:, ~df.columns.str.contains(r"\.\.\.")]  # Drop columns with '...'

    # Split columns into ranges and intensities
    num_cols = df.shape[1]
    if num_cols % 2 != 0:
        error_output = "Remaining columns after cleaning must be even to split into ranges and intensities."
        return None, None, None, error_output

    half_cols = num_cols // 2
    ranges = df.iloc[:, :half_cols].to_numpy()
    intensities = df.iloc[:, half_cols:].to_numpy()

    # LiDAR system angle limits
    system_min_rad = -3.12413907  # approx -179°
    system_max_rad = 3.14159274   # approx 180°

    # Compute angle array
    num_beams = ranges.shape[1]
    angles_rad_full = np.linspace(system_min_rad, system_max_rad, num_beams)

    # Mask for angle range (wrap-around support)
    if min_angle_rad < max_angle_rad:
        mask = (angles_rad_full >= min_angle_rad) & (angles_rad_full <= max_angle_rad)
    else:
        mask = (angles_rad_full >= min_angle_rad) | (angles_rad_full <= max_angle_rad)

    if not np.any(mask):
        error_output = f"No beams found between {min_angle_deg}° and {max_angle_deg}°."
        return None, None, None, error_output

    # Initialize lists
    theta_all, r_all, colors, intensity_all = [], [], [], []

    # Iterate through rows
    for row_idx in range(ranges.shape[0]):
        row_ranges = ranges[row_idx].astype(float)
        row_intensities = intensities[row_idx].astype(float)

        # Apply min/max cutoff
        valid_mask = mask & ~np.isinf(row_ranges)
        if min_cutoff is not None:
            valid_mask = valid_mask & (row_ranges >= round(float(min_cutoff), 15))
        if max_cutoff is not None:
            valid_mask = valid_mask & (row_ranges <= round(float(max_cutoff), 15))

        if not np.any(valid_mask):
            continue

        theta_all.extend(np.rad2deg(angles_rad_full[valid_mask]))
        r_all.extend(row_ranges[valid_mask])
        intensity_all.extend(row_intensities[valid_mask])
        colors.extend(["red" if val == 47.0 else "black" for val in row_intensities[valid_mask]])

    if len(theta_all) == 0 or len(r_all) == 0:
        error_output = (f"No valid data to plot for {min_angle_deg}° to {max_angle_deg}° "
                        "(possibly due to inf values or cutoff).")
        return None, None, None, error_output

    # Dynamic ticks and axis limits
    max_range = max_cutoff if max_cutoff is not None else max(r_all)
    tick_values = np.linspace(max_range / 4, max_range, 4).round(2)

    # Convert to Cartesian (corrected)
    theta_rad_all = np.deg2rad(theta_all)
    x_all = np.array(r_all) * np.cos(theta_rad_all)  # Forward distance
    y_all = np.array(r_all) * np.sin(theta_rad_all)  # Lateral offset

    # Create subplot: Polar + Cartesian
    fig = make_subplots(rows=1, cols=2,
                        subplot_titles=("Polar LiDAR Plot", "Cartesian Global View"),
                        specs=[[{"type": "polar"}, {"type": "scatter"}]])

    # Polar plot
    fig.add_trace(go.Scatterpolar(
        r=r_all,
        theta=theta_all,
        mode='markers',
        marker=dict(color=colors, size=4),
        showlegend=False
    ), row=1, col=1)

    # Cartesian plot
    fig.add_trace(go.Scatter(
        x=x_all,
        y=y_all,
        mode='markers',
        marker=dict(color=colors, size=4),
        showlegend=False
    ), row=1, col=2)

    # Add dummy traces for legend
    fig.add_trace(go.Scatterpolar(
        r=[None], theta=[None],
        mode='markers',
        marker=dict(color='red', size=6),
        name='Intensity = 47'
    ), row=1, col=1)
    fig.add_trace(go.Scatterpolar(
        r=[None], theta=[None],
        mode='markers',
        marker=dict(color='black', size=6),
        name='Intensity = 0'
    ), row=1, col=1)

    # Update layout
    fig.update_layout(
        title=f"LiDAR Visualization: {min_angle_deg}° to {max_angle_deg}°",
        polar=dict(
            radialaxis=dict(visible=True,
                            range=[0, max_range],
                            tickvals=tick_values,
                            ticktext=[str(v) for v in tick_values]),
            angularaxis=dict(direction="counterclockwise", rotation=0,
                             tickmode="array",
                             tickvals=[0, 90, 180, 270],
                             ticktext=["0°", "90°", "180°", "-90°"])
        ),
        width=1200,
        height=800,
        legend=dict(x=1.05, y=1)
    )

    # Cartesian: keep grid, remove labels
    fig.update_xaxes(range=[-max_range, max_range],
                     showticklabels=False,
                     title=None,
                     showgrid=True,
                     row=1, col=2)
    fig.update_yaxes(range=[-max_range, max_range],
                     showticklabels=False,
                     title=None,
                     showgrid=True,
                     row=1, col=2)

    return fig, np.array(r_all), np.array(intensity_all), error_output

# CSV creation
def create_csv(points_array, intensity_array, reference_distance, color):
    points_array = np.array(points_array)
    num_points = len(points_array)
    df = pd.DataFrame({
        'No.': range(1, num_points + 1),
        'Color': [color] * num_points,
        'Reference Distance': [reference_distance] * num_points,
        'Measured LiDAR Distance': points_array,
        'Point Intensity': intensity_array
    })
    filename = f"{color}_{reference_distance}.csv"
    df.to_csv(filename, index=False)
    return f"CSV saved as {filename}", df

# Gradio interface
def filter_points(csv_file, min_angle, max_angle, min_cutoff, max_cutoff):
    df = pd.read_csv(csv_file.name)
    fig, points, intensities, error = target_angle_range(df, min_angle, max_angle, min_cutoff, max_cutoff)
    return fig, points.tolist() if points is not None else [], intensities.tolist() if intensities is not None else [], error

def generate_csv(points, intensities, reference_distance, color):
    if not points:
        return "No points to save.", None
    msg, df = create_csv(points, intensities, reference_distance, color)
    return msg, df

# Main function for CLI entry point
def main():
    try:
        with gr.Blocks() as demo:
            gr.Markdown("# LiDAR Data Processing Tool", elem_id="title")
            with gr.Row():
                csv_input = gr.File(label="Upload CSV File")
                min_angle = gr.Number(label="Min Angle (deg)", value=-179)
                max_angle = gr.Number(label="Max Angle (deg)", value=180)
                min_cutoff = gr.Number(label="Min Range Cutoff", value=0)
                max_cutoff = gr.Number(label="Max Range Cutoff", value=9)
            with gr.Row():
                reference_distance = gr.Number(label="Reference Distance", value=1)
                color = gr.Textbox(label="Color", value="white")
                filter_btn = gr.Button("Filter Points")
                generate_btn = gr.Button("Generate CSV")
            error_status = gr.Textbox(label="Error")
            plot_output = gr.Plot(label="LiDAR Plot")
            csv_status = gr.Textbox(label="CSV Status")
            df_output = gr.Dataframe(label="Generated DataFrame")
            points_state = gr.State()
            intensity_state = gr.State()
            filter_btn.click(filter_points, inputs=[csv_input, min_angle, max_angle, min_cutoff, max_cutoff],
                             outputs=[plot_output, points_state, intensity_state, error_status])
            generate_btn.click(generate_csv, inputs=[points_state, intensity_state, reference_distance, color],
                               outputs=[csv_status, df_output])
            demo.load(lambda: "App ready. If you encounter errors, check your CSV format.", None, None)
            demo.launch(theme="dark", inbrowser=True)
    except KeyboardInterrupt:
        print("\n👋 Server interrupted. Exiting app session...")
    except Exception as e:
        print(f"Unexpected Error: {e}")

if __name__ == "__main__":
    main()
