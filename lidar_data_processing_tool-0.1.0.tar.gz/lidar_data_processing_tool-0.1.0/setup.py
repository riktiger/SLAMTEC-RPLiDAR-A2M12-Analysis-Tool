
from setuptools import setup, find_packages

setup(
    name="lidar_data_processing_tool",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "gradio>=6.0",
        "plotly>=6.5",
        "pandas>=2.3",
        "numpy>=2.3"
    ],
    entry_points={
        "console_scripts": [
            "lidar_app=lidar_data_processing_tool.app:main"
        ]
    },
    description="LiDAR data visualization and CSV export tool",
    author="Aritra Bag",
    author_email="aritrabag@hotmail.com",
    license="MIT",
    python_requires=">=3.12",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
        "Topic :: Scientific/Engineering :: Visualization"
    ],
)